﻿namespace Negocio.ValoracionesPorISIN.ConParameterObject
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
