﻿namespace Negocio.Valoraciones.ComoUnProcedimiento
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
