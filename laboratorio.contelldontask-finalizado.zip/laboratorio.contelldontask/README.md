# Laboratorio.ConTellDontAsk
Este laboratorio nos permite practicar principio de Tell, Don't Ask de la orientación a objetos.