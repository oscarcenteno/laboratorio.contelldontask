# Laboratorio.ConTellDontAsk
Este laboratorio nos permite practicar principio de Tell, Don't Ask de la orientación a objetos.

[![Build status](https://ci.appveyor.com/api/projects/status/uxpd5asqqanj7j39?svg=true)](https://ci.appveyor.com/project/oscarcenteno/laboratorio-contelldontask)
