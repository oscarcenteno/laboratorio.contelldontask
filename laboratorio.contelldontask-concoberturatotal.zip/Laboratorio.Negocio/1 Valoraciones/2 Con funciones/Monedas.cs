﻿namespace Negocio.Valoraciones.ConFunciones
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
