﻿namespace Negocio.Valoraciones.ConParameterObject
{
    public enum Monedas
    {
        Colon,
        USDolar,
        UDEs
    }
}
