﻿namespace Negocio.ValoracionesPorISIN.ConTellDontAsk
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
