﻿namespace Negocio.ValoracionesPorISIN.ConFunciones
{
    public enum Monedas
    {
        UDES,
        Colon,
        Dolar
    }
}
